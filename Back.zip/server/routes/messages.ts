import express from 'express';
import { auth } from '../middleware/auth';
import Message from '../models/Message';

const router = express.Router();

router.post('/send', auth, async (req, res) => {
  try {
    const { receiverId, content } = req.body;
    const message = new Message({
      sender: req.user.userId,
      receiver: receiverId,
      content
    });
    await message.save();
    res.status(201).json(message);
  } catch (error) {
    res.status(400).json({ error: 'Failed to send message' });
  }
});

router.get('/conversations', auth, async (req, res) => {
  try {
    const messages = await Message.find({
      $or: [
        { sender: req.user.userId },
        { receiver: req.user.userId }
      ]
    })
    .sort('-createdAt')
    .populate('sender receiver', 'username');
    res.json(messages);
  } catch (error) {
    res.status(400).json({ error: 'Failed to fetch messages' });
  }
});

export default router;