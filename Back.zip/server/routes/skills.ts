import express from 'express';
import { auth } from '../middleware/auth';
import User from '../models/User';

const router = express.Router();

router.get('/search', auth, async (req, res) => {
  try {
    const { skill } = req.query;
    const users = await User.find({
      $or: [
        { skillsToTeach: { $regex: skill, $options: 'i' } },
        { skillsToLearn: { $regex: skill, $options: 'i' } }
      ]
    }).select('-password');
    res.json(users);
  } catch (error) {
    res.status(400).json({ error: 'Search failed' });
  }
});

router.put('/update', auth, async (req, res) => {
  try {
    const { skillsToTeach, skillsToLearn } = req.body;
    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { $set: { skillsToTeach, skillsToLearn } },
      { new: true }
    ).select('-password');
    res.json(user);
  } catch (error) {
    res.status(400).json({ error: 'Failed to update skills' });
  }
});

export default router;