import React from 'react';

const Hero = () => {
  return (
    <div className="bg-indigo-700 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 flex items-center">
        <div className="w-1/2">
          <h1 className="text-5xl font-bold mb-6">Exchange Skills, Grow Together</h1>
          <p className="text-xl mb-8">Connect with people around the world to learn new skills and share your expertise.</p>
          <button className="bg-white text-indigo-700 font-semibold py-3 px-6 rounded-lg hover:bg-indigo-100 transition duration-300">
            Get Started
          </button>
        </div>
        <div className="w-1/2">
          <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1471&q=80" alt="People collaborating" className="rounded-lg shadow-xl" />
        </div>
      </div>
    </div>
  );
};

export default Hero;