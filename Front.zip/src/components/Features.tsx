import React from 'react';
import { BookOpen, Users, MessageCircle } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <BookOpen className="h-12 w-12 text-indigo-600" />,
      title: 'Learn New Skills',
      description: 'Access a wide range of skills taught by experienced individuals from around the world.'
    },
    {
      icon: <Users className="h-12 w-12 text-indigo-600" />,
      title: 'Build Connections',
      description: 'Connect with like-minded people and form lasting relationships based on shared interests.'
    },
    {
      icon: <MessageCircle className="h-12 w-12 text-indigo-600" />,
      title: 'Real-time Communication',
      description: 'Engage in seamless, real-time conversations with your skill exchange partners.'
    }
  ];

  return (
    <div className="bg-white py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12">Why Choose SkillSwitch?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className="flex justify-center mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;