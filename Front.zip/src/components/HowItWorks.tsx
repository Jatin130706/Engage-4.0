import React from 'react';

const HowItWorks = () => {
  const steps = [
    { number: '01', title: 'Create Your Profile', description: 'Sign up and list the skills you want to learn and teach.' },
    { number: '02', title: 'Find a Match', description: 'Browse profiles and connect with users who complement your skill set.' },
    { number: '03', title: 'Schedule Sessions', description: 'Agree on a time and platform for your skill exchange sessions.' },
    { number: '04', title: 'Start Learning', description: 'Begin your journey of mutual growth and skill development.' }
  ];

  return (
    <div className="bg-gray-100 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12">How SkillSwitch Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-4xl font-bold text-indigo-600 mb-4">{step.number}</div>
              <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HowItWorks;